<?php
if(get_theme_mod('bazola_single_image_zoom') == 1 || bazola_ft() == 'imgzoom'){
	
/*************************************************
## Scripts
*************************************************/
function bazola_image_zoom_scripts() {
	wp_register_style( 'th-image-zoom',   plugins_url( 'css/image-zoom.css', __FILE__ ), false, '1.0');
	wp_register_script( 'jquery-zoom',   plugins_url( 'js/jquery.zoom.min.js', __FILE__ ), false, '1.0');
	wp_register_script( 'th-image-zoom',   plugins_url( 'js/image-zoom.js', __FILE__ ), false, '1.0');

}
add_action( 'wp_enqueue_scripts', 'bazola_image_zoom_scripts' );


add_action('woocommerce_product_thumbnails','th_image_zoom',20);
function th_image_zoom(){
	wp_enqueue_style('th-image-zoom');
	wp_enqueue_script('jquery-zoom');
	wp_enqueue_script('th-image-zoom');
}


function bazola_image_zoom_setup() {
	add_theme_support( 'wc-product-gallery-zoom' );
}
add_action( 'after_setup_theme', 'bazola_image_zoom_setup' );

}