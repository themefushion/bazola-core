<?php

/*************************************************
## Scripts
*************************************************/
function bazola_product_data_video_scripts() {
	wp_register_style( 'th-product-data-video',   plugins_url( 'css/product-data-video.css', __FILE__ ), false, '1.0');
	wp_register_script( 'th-product-data-video',   plugins_url( 'js/product-data-video.js', __FILE__ ), false, '1.0');

}
add_action( 'wp_enqueue_scripts', 'bazola_product_data_video_scripts' );

add_filter('woocommerce_product_data_tabs', function($tabs) {
	$tabs['th_video_info'] = [
		'label' => esc_html__('Video', 'txtdomain'),
		'target' => 'th_video_product_data',
		'class' => ['hide_if_external'],
		'priority' => 60
	];
	return $tabs;
});

add_action('woocommerce_product_data_panels', function() {
	?><div id="th_video_product_data" class="panel woocommerce_options_panel hidden"><?php
 
	woocommerce_wp_textarea_input([
		'id' => '_th_single_video_input',
		'label' => esc_html__('Video URL', 'bazola-core'),
		'wrapper_class' => 'show_if_simple',
		'desc_tip'    => true,
		'description' => esc_html__( 'Enter a youtube or a vimeo video url for the single product.', 'bazola-core' ),
	]);
 
	?></div><?php
});

add_action('woocommerce_process_product_meta', function($post_id) {
	$product = wc_get_product($post_id);
	
	$product->update_meta_data('_th_single_video_input', sanitize_text_field($_POST['_th_single_video_input']));
 

	$product->save();
});


add_action('woocommerce_product_thumbnails','th_product_data_video',20);
function th_product_data_video(){
	$product = wc_get_product(get_the_ID());
	$videourl = $product->get_meta('_th_single_video_input');	
	
	if($videourl){
		wp_enqueue_style('th-product-data-video');
		wp_enqueue_script('th-product-data-video');

		if (strpos($videourl, 'vimeo') !== false) {
			$videoclass = "popup-vimeo";
		} else{
			$videoclass = "popup-youtube";
		}
		
		echo '<div class="th-single-video"><a class="'.esc_attr($videoclass).'" href="'.esc_url($videourl).'"><span>'.esc_html__('Watch video','bazola-core').'</span></a></div>';

	}

}