<?php

/*************************************************
## Scripts
*************************************************/
function bazola_remove_all_button_scripts() {
	wp_register_script( 'th-remove-all',   plugins_url( 'js/remove-all.js', __FILE__ ), false, '1.0');
	wp_register_style( 'th-remove-all',   plugins_url( 'css/remove-all.css', __FILE__ ), false, '1.0');
}
add_action( 'wp_enqueue_scripts', 'bazola_remove_all_button_scripts' );


/*************************************************
## Remove All Button
*************************************************/ 

add_action( 'woocommerce_cart_actions', 'bazola_remove_all_button' );
function bazola_remove_all_button() {
	
	if(!is_cart()){
		return;
	}
	
	wp_enqueue_script( 'th-remove-all');
	wp_enqueue_style( 'th-remove-all');
	
	echo '<a href="#" class="button remove-all">'.esc_html__( 'Remove All', 'bazola-core' ).'</a>';
}

add_action( 'wp_ajax_nopriv_remove_all_from_cart', 'bazola_remove_all_from_cart_callback' );
add_action( 'wp_ajax_remove_all_from_cart', 'bazola_remove_all_from_cart_callback' );
function bazola_remove_all_from_cart_callback() {
	WC()->cart->empty_cart();
}