<?php

/*************************************************
## Scripts
*************************************************/
function bazola_newsletter_scripts() {
	wp_register_style( 'th-newsletter',   plugins_url( 'css/newsletter.css', __FILE__ ), false, '1.0');
	wp_register_script( 'th-newsletter',  plugins_url( 'js/newsletter.js', __FILE__ ), true );

}
add_action( 'wp_enqueue_scripts', 'bazola_newsletter_scripts' );

add_action('wp_footer', 'bazola_newsletter_filter'); 
function bazola_newsletter_filter() { 

	if ( ! apply_filters( 'bazola_newsletter_filter', true ) ) {
		return;
	}

	if(get_theme_mod('bazola_newsletter_popup_toggle',0) == 1){
		wp_enqueue_script('jquery-cookie');
		wp_enqueue_script('th-newsletter');
		wp_enqueue_style('th-newsletter');

		$newsletter  = isset( $_COOKIE['newsletter-popup-visible'] ) ? $_COOKIE['newsletter-popup-visible'] : 'hide';
		
		if($newsletter == 'disable'){
			return;
		}

		?>
		
		  <div id="newsletter-popup" class="site-newsletter" style="opacity:0;" data-expires="<?php echo esc_attr(get_theme_mod('bazola_newsletter_popup_expire_date')); ?>">
			<div class="newsletter-wrapper">
			  <div class="newsletter-inner">

				<div class="newsletter-close">
				  <i class="thth-icon-x"></i>
				</div><!-- newsletter-close -->

				<h5 class="entry-title"><?php echo esc_html(get_theme_mod('bazola_newsletter_popup_title')); ?></h5>

				<div class="entry-desc">
				  <p><?php echo bazola_sanitize_data(get_theme_mod('bazola_newsletter_popup_subtitle')); ?></p>
				</div><!-- entry-desc -->

				<div class="site-newsletter-form">
					<?php echo do_shortcode('[mc4wp_form id="'.get_theme_mod('bazola_newsletter_popup_formid').'"]'); ?>
				</div>
				
				<p>
					<label class="form-checkbox privacy_policy">
						<input type="checkbox" name="dontshow" class="dontshow" value="1">
						<span><?php esc_html_e('Don\'t show this popup again.','bazola-core'); ?></span>
					</label>
				</p>


			  </div><!-- newsletter-inner -->
			  <div class="newsletter-popup-overlay"></div>
			</div><!-- newsletter-wrapper -->
			
		  </div><!-- site-newsletter -->

		<?php
	}
}